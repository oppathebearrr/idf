async function injectContentScript(tabId, panel = "") {
  try {
    const enabled = await new Promise((resolve) => {
      chrome.storage.local.get(["content-rules"], (value) => {
        const rules = value["content-rules"];
        resolve(!(rules && typeof rules === "object" && rules.enabled === false));
      });
    });
    if (!enabled) return;

    await new Promise((resolve) => {
      chrome.tabs.sendMessage(tabId, { type: "replay-persistent-rules" }, () => {
        void chrome.runtime.lastError;
        resolve();
      });
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/pages/content/index.js"],
    });
    if (panel) {
      await new Promise((resolve) => {
        chrome.tabs.sendMessage(
          tabId,
          { type: "open-persistent-rules" },
          () => {
            void chrome.runtime.lastError;
            resolve();
          },
        );
      });
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.warn(`Inspect CSS could not attach to tab ${tabId}: ${message}`);
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (typeof tab.id !== "number") return;
  const isBrowserOwnedPage =
    !tab.url ||
    !/^(https?|file):/i.test(tab.url) ||
    /^(https?:\/\/)?(chromewebstore\.google\.com|chrome\.google\.com\/webstore)/i.test(
      tab.url,
    );
  if (isBrowserOwnedPage) {
    console.warn(
      "Inspect CSS cannot run on browser-controlled pages. Open a normal website first.",
    );
    return;
  }
  injectContentScript(tab.id);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "open-inspector") {
    const tabId =
      typeof message.tabId === "number" ? message.tabId : sender.tab?.id;
    if (typeof tabId !== "number") {
      sendResponse({ opened: false });
      return;
    }
    injectContentScript(tabId, message.panel === "rules" ? "rules" : "")
      .then(() => sendResponse({ opened: true }))
      .catch(() => sendResponse({ opened: false }));
    return true;
  }

  if (message?.name !== "background:screenshot-tab") return;
  if (!sender.tab?.windowId) {
    sendResponse("");
    return;
  }
  chrome.tabs
    .captureVisibleTab(sender.tab.windowId, { quality: 70 })
    .then(sendResponse);
  return true;
});

console.log("background loaded");
